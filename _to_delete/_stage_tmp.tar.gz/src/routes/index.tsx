import { createFileRoute } from "@tanstack/react-router";

import { GanttMarcenaria } from "@/components/GanttMarcenaria";
import { GanttProvider } from "@/lib/gantt-store";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Cronograma da Marcenaria | Gantt da Equipe" },
      {
        name: "description",
        content:
          "Diagrama de Gantt para marcenaria: acompanhe obras por colaborador e por dia, com opção de inverter linhas e colunas.",
      },
      { property: "og:title", content: "Cronograma da Marcenaria | Gantt da Equipe" },
      {
        property: "og:description",
        content:
          "Planejamento visual da oficina: colaboradores nas linhas, linha do tempo nas colunas — e o inverso em um clique.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <main className="min-h-screen px-3 py-6 sm:px-4 sm:py-8 md:px-8">
      <div className="mx-auto max-w-6xl space-y-6 md:space-y-8">
        <div className="border-b border-border pb-6">
          <p className="text-xs font-semibold uppercase tracking-[0.25em] text-primary">
            Marcenaria Serra & Cavaco
          </p>
          <h1 className="mt-2 text-3xl leading-none sm:text-5xl md:text-6xl">Planejamento de produção</h1>
          <p className="mt-3 max-w-xl text-sm text-muted-foreground">
            Quem está em qual obra, em qual etapa e por quantos dias. Inverta os eixos para ler o
            cronograma por data ou por colaborador.
          </p>
        </div>

        <GanttProvider>
          <GanttMarcenaria />
        </GanttProvider>
      </div>
    </main>
  );
}
