import { useState } from "react";
import { Pencil, Plus, Settings2, Trash2 } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { faseClass, faseLabel, type Dia, type Fase, type Tarefa } from "@/lib/gantt-data";
import { useGantt } from "@/lib/gantt-store";

const fases = Object.keys(faseLabel) as Fase[];

export function GerenciarDialog({ dias }: { dias: Dia[] }) {
  const {
    colaboradores,
    tarefas,
    salvarColaborador,
    removerColaborador,
    salvarTarefa,
    removerTarefa,
    desfazer,
  } = useGantt();

  function avisarComRefazer(mensagem = "Ação desfeita.") {
    toast(mensagem, {
      action: {
        label: "Refazer",
        onClick: () => {
          refazer();
          avisarComDesfazer("Ação refeita.");
        },
      },
      duration: 6000,
    });
  }

  function avisarComDesfazer(mensagem: string) {
    toast(mensagem, {
      action: {
        label: "Desfazer",
        onClick: () => {
          desfazer();
          avisarComRefazer();
        },
      },
      duration: 6000,
    });
  }

  const [aberto, setAberto] = useState(false);

  // formulário de colaborador
  const [colabId, setColabId] = useState<string | undefined>();
  const [nome, setNome] = useState("");
  const [funcao, setFuncao] = useState("");

  // formulário de serviço
  const [tarefaId, setTarefaId] = useState<string | undefined>();
  const [obra, setObra] = useState("");
  const [clienteNome, setClienteNome] = useState("");
  const [fase, setFase] = useState<Fase>("corte");
  const [responsavel, setResponsavel] = useState("");
  const [inicio, setInicio] = useState("0");
  const [dias_, setDias] = useState("2");

  const limparColab = () => {
    setColabId(undefined);
    setNome("");
    setFuncao("");
  };

  const limparTarefa = () => {
    setTarefaId(undefined);
    setObra("");
    setClienteNome("");
    setFase("corte");
    setResponsavel(colaboradores[0]?.id ?? "");
    setInicio("0");
    setDias("2");
  };

  const editarColab = (id: string) => {
    const c = colaboradores.find((x) => x.id === id);
    if (!c) return;
    setColabId(c.id);
    setNome(c.nome);
    setFuncao(c.funcao);
  };

  const editarTarefa = (t: Tarefa) => {
    setTarefaId(t.id);
    setObra(t.obra);
    setClienteNome(t.cliente);
    setFase(t.fase);
    setResponsavel(t.colaboradorId);
    setInicio(String(t.inicio));
    setDias(String(t.dias));
  };

  const submeterColab = () => {
    if (!nome.trim()) return;
    salvarColaborador({ id: colabId, nome: nome.trim(), funcao: funcao.trim() || "Marcenaria" });
    avisarComDesfazer(
      colabId ? `Funcionário "${nome.trim()}" atualizado.` : `Funcionário "${nome.trim()}" adicionado.`,
    );
    limparColab();
  };

  const submeterTarefa = () => {
    const resp = responsavel || colaboradores[0]?.id;
    if (!obra.trim() || !resp) return;
    salvarTarefa({
      id: tarefaId,
      obra: obra.trim(),
      cliente: clienteNome.trim() || "Sem cliente",
      fase,
      colaboradorId: resp,
      inicio: Number(inicio),
      dias: Math.max(1, Number(dias_) || 1),
    });
    avisarComDesfazer(
      tarefaId ? `Serviço "${obra.trim()}" atualizado.` : `Serviço "${obra.trim()}" adicionado.`,
    );
    limparTarefa();
  };

  return (
    <Dialog
      open={aberto}
      onOpenChange={(v) => {
        setAberto(v);
        if (v) {
          limparColab();
          limparTarefa();
        }
      }}
    >
      <DialogTrigger asChild>
        <Button variant="secondary">
          <Settings2 className="mr-2 size-4" />
          Gerenciar
        </Button>
      </DialogTrigger>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>Equipe e serviços</DialogTitle>
          <DialogDescription>
            Cadastre funcionários da marcenaria e os serviços do cronograma.
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="funcionarios">
          <TabsList className="w-full">
            <TabsTrigger value="funcionarios" className="flex-1">
              Funcionários
            </TabsTrigger>
            <TabsTrigger value="servicos" className="flex-1">
              Serviços
            </TabsTrigger>
          </TabsList>

          <TabsContent value="funcionarios" className="space-y-4 pt-4">
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="nome">Nome</Label>
                <Input
                  id="nome"
                  value={nome}
                  onChange={(e) => setNome(e.target.value)}
                  placeholder="Ex.: João Batista"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="funcao">Função</Label>
                <Input
                  id="funcao"
                  value={funcao}
                  onChange={(e) => setFuncao(e.target.value)}
                  placeholder="Ex.: Montador"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <Button onClick={submeterColab}>
                <Plus className="mr-2 size-4" />
                {colabId ? "Salvar alterações" : "Adicionar funcionário"}
              </Button>
              {colabId && (
                <Button variant="ghost" onClick={limparColab}>
                  Cancelar
                </Button>
              )}
            </div>

            <ul className="divide-y divide-border rounded-md border border-border">
              {colaboradores.map((c) => (
                <li key={c.id} className="flex items-center gap-2 p-3">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold">{c.nome}</p>
                    <p className="truncate text-xs text-muted-foreground">{c.funcao}</p>
                  </div>
                  <Button variant="ghost" size="icon" onClick={() => editarColab(c.id)}>
                    <Pencil className="size-4" />
                    <span className="sr-only">Editar {c.nome}</span>
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => {
                      removerColaborador(c.id);
                      avisarComDesfazer(`Funcionário "${c.nome}" removido.`);
                    }}
                  >
                    <Trash2 className="size-4 text-destructive" />
                    <span className="sr-only">Remover {c.nome}</span>
                  </Button>
                </li>
              ))}
              {colaboradores.length === 0 && (
                <li className="p-3 text-sm text-muted-foreground">Nenhum funcionário cadastrado.</li>
              )}
            </ul>
          </TabsContent>

          <TabsContent value="servicos" className="space-y-4 pt-4">
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1.5 sm:col-span-2">
                <Label htmlFor="obra">Serviço / obra</Label>
                <Input
                  id="obra"
                  value={obra}
                  onChange={(e) => setObra(e.target.value)}
                  placeholder="Ex.: Guarda-roupa Apto 51"
                />
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <Label htmlFor="cliente">Cliente</Label>
                <Input
                  id="cliente"
                  value={clienteNome}
                  onChange={(e) => setClienteNome(e.target.value)}
                  placeholder="Ex.: Fernanda Rocha"
                />
              </div>
              <div className="space-y-1.5">
                <Label>Etapa</Label>
                <Select value={fase} onValueChange={(v) => setFase(v as Fase)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {fases.map((f) => (
                      <SelectItem key={f} value={f}>
                        {faseLabel[f]}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Responsável</Label>
                <Select
                  value={responsavel || colaboradores[0]?.id || ""}
                  onValueChange={setResponsavel}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Escolha" />
                  </SelectTrigger>
                  <SelectContent>
                    {colaboradores.map((c) => (
                      <SelectItem key={c.id} value={c.id}>
                        {c.nome}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Início</Label>
                <Select value={inicio} onValueChange={setInicio}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {dias.map((d) => (
                      <SelectItem key={d.index} value={String(d.index)}>
                        {d.label} ({d.diaSemana})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="duracao">Duração (dias)</Label>
                <Input
                  id="duracao"
                  type="number"
                  min={1}
                  max={dias.length}
                  value={dias_}
                  onChange={(e) => setDias(e.target.value)}
                />
              </div>
            </div>
            <div className="flex gap-2">
              <Button onClick={submeterTarefa}>
                <Plus className="mr-2 size-4" />
                {tarefaId ? "Salvar alterações" : "Adicionar serviço"}
              </Button>
              {tarefaId && (
                <Button variant="ghost" onClick={limparTarefa}>
                  Cancelar
                </Button>
              )}
            </div>

            <ul className="divide-y divide-border rounded-md border border-border">
              {tarefas.map((t) => (
                <li key={t.id} className="flex items-center gap-2 p-3">
                  <span className={`size-3 shrink-0 rounded-sm ${faseClass[t.fase]}`} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold">{t.obra}</p>
                    <p className="truncate text-xs text-muted-foreground">
                      {t.cliente} ·{" "}
                      {colaboradores.find((c) => c.id === t.colaboradorId)?.nome ?? "Sem responsável"}
                      {" · "}
                      {dias[t.inicio]?.label ?? "?"} · {t.dias} dias
                    </p>
                  </div>
                  <Button variant="ghost" size="icon" onClick={() => editarTarefa(t)}>
                    <Pencil className="size-4" />
                    <span className="sr-only">Editar {t.obra}</span>
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => {
                      removerTarefa(t.id);
                      avisarComDesfazer(`Serviço "${t.obra}" excluído.`);
                    }}
                  >
                    <Trash2 className="size-4 text-destructive" />
                    <span className="sr-only">Remover {t.obra}</span>
                  </Button>
                </li>
              ))}
              {tarefas.length === 0 && (
                <li className="p-3 text-sm text-muted-foreground">Nenhum serviço cadastrado.</li>
              )}
            </ul>
          </TabsContent>
        </Tabs>

        <DialogFooter>
          <Badge variant="outline" className="mr-auto font-normal">
            {colaboradores.length} funcionários · {tarefas.length} serviços
          </Badge>
          <Button variant="secondary" onClick={() => setAberto(false)}>
            Fechar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
