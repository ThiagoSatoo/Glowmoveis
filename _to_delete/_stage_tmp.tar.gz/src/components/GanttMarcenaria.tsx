import { useMemo, useState } from "react";
import { ArrowLeftRight, Hammer, Redo, RotateCcw, Search, Undo, X, ZoomIn, ZoomOut } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { GerenciarDialog } from "@/components/GerenciarDialog";
import { EdicaoRapidaDialog } from "@/components/EdicaoRapidaDialog";
import { MontadorPainel } from "@/components/MontadorPainel";
import {
  faseClass,
  faseLabel,
  gerarDias,
  periodoDias,
  periodoLabel,
  type Fase,
  type Periodo,
  type Tarefa,
} from "@/lib/gantt-data";
import { useGantt } from "@/lib/gantt-store";

type Orientacao = "colaboradores-linhas" | "colaboradores-colunas";

const ZOOM_MIN = 0.6;
const ZOOM_MAX = 2;
const ZOOM_PASSO = 0.2;

const clamp = (v: number) => Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, Number(v.toFixed(2))));

export function GanttMarcenaria() {
  const [orientacao, setOrientacao] = useState<Orientacao>("colaboradores-linhas");
  const [zoom, setZoom] = useState(1);
  const [periodo, setPeriodo] = useState<Periodo>("semana");
  const [cliente, setCliente] = useState("");
  const [montadorId, setMontadorId] = useState("todos");
  const [tarefaEditando, setTarefaEditando] = useState<Tarefa | null>(null);
  const dias = useMemo(() => gerarDias(periodoDias[periodo]), [periodo]);
  const {
    colaboradores: todosColaboradores,
    tarefas: todasTarefas,
    desfazer,
    refazer,
    podeDesfazer,
    podeRefazer,
  } = useGantt();

  const ultimoDia = dias.length - 1;
  const montadorSelecionado =
    montadorId === "todos" ? null : (todosColaboradores.find((c) => c.id === montadorId) ?? null);

  const clienteBusca = cliente.trim().toLowerCase();

  const tarefas = useMemo(
    () =>
      todasTarefas.filter((t) => {
        const dentroDoPeriodo = t.inicio <= ultimoDia && t.inicio + t.dias - 1 >= 0;
        const clienteOk =
          !clienteBusca ||
          t.cliente.toLowerCase().includes(clienteBusca) ||
          t.obra.toLowerCase().includes(clienteBusca);
        const montadorOk = montadorId === "todos" || t.colaboradorId === montadorId;
        return dentroDoPeriodo && clienteOk && montadorOk;
      }),
    [todasTarefas, ultimoDia, clienteBusca, montadorId],
  );

  const colaboradores = useMemo(
    () =>
      montadorSelecionado
        ? todosColaboradores.filter((c) => c.id === montadorSelecionado.id)
        : todosColaboradores,
    [todosColaboradores, montadorSelecionado],
  );

  const filtrosAtivos = periodo !== "semana" || !!clienteBusca || montadorId !== "todos";
  const colabPorLinha = orientacao === "colaboradores-linhas";

  const eixoPrincipal = colabPorLinha ? colaboradores.length : dias.length;
  const eixoSecundario = colabPorLinha ? dias.length : colaboradores.length;

  const gridStyle = colabPorLinha
    ? {
        gridTemplateColumns: `${10.5 * zoom}rem repeat(${dias.length}, minmax(${3.25 * zoom}rem, 1fr))`,
        gridTemplateRows: `auto repeat(${colaboradores.length}, ${3.5 * zoom}rem)`,
        fontSize: `${zoom}rem`,
      }
    : {
        gridTemplateColumns: `${5.5 * zoom}rem repeat(${colaboradores.length}, minmax(${7 * zoom}rem, 1fr))`,
        gridTemplateRows: `auto repeat(${dias.length}, ${2.75 * zoom}rem)`,
        fontSize: `${zoom}rem`,
      };

  return (
    <section className="space-y-4">
      <header className="flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-end sm:justify-between">
        <div className="min-w-0">
          <h2 className="text-2xl leading-none sm:text-3xl">Cronograma da oficina</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            {colabPorLinha
              ? "Colaboradores nas linhas · dias nas colunas"
              : "Dias nas linhas · colaboradores nas colunas"}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex shrink-0 items-center gap-1 rounded-md border border-border bg-card p-1">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setZoom((z) => clamp(z - ZOOM_PASSO))}
              disabled={zoom <= ZOOM_MIN}
              aria-label="Diminuir zoom"
            >
              <ZoomOut className="size-4" />
            </Button>
            <span className="w-12 text-center text-xs font-semibold tabular-nums">
              {Math.round(zoom * 100)}%
            </span>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setZoom((z) => clamp(z + ZOOM_PASSO))}
              disabled={zoom >= ZOOM_MAX}
              aria-label="Aumentar zoom"
            >
              <ZoomIn className="size-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setZoom(1)}
              disabled={zoom === 1}
              aria-label="Redefinir zoom"
            >
              <RotateCcw className="size-4" />
            </Button>
          </div>

          <div className="flex shrink-0 items-center gap-1 rounded-md border border-border bg-card p-1">
            <Button
              variant="ghost"
              size="icon"
              onClick={desfazer}
              disabled={!podeDesfazer}
              aria-label="Desfazer"
            >
              <Undo className="size-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={refazer}
              disabled={!podeRefazer}
              aria-label="Refazer"
            >
              <Redo className="size-4" />
            </Button>
          </div>

          <GerenciarDialog dias={dias} />

          <Button
            className="flex-1 sm:flex-none"
            onClick={() =>
              setOrientacao((o) =>
                o === "colaboradores-linhas" ? "colaboradores-colunas" : "colaboradores-linhas",
              )
            }
          >
            <ArrowLeftRight className="mr-2 size-4 shrink-0" />
            <span className="truncate">Inverter eixos</span>
          </Button>
        </div>
      </header>

      <div className="flex flex-col gap-3 rounded-lg border border-border bg-card p-3 sm:flex-row sm:flex-wrap sm:items-end">
        <div className="grid grid-cols-4 gap-1 rounded-md border border-border p-1 sm:flex sm:items-center">
          {(Object.keys(periodoLabel) as Periodo[]).map((p) => (
            <Button
              key={p}
              size="sm"
              variant={periodo === p ? "default" : "ghost"}
              onClick={() => setPeriodo(p)}
              className="px-2 sm:px-3"
            >
              {periodoLabel[p]}
            </Button>
          ))}
        </div>

        <div className="relative w-full min-w-0 sm:min-w-[12rem] sm:flex-1">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={cliente}
            onChange={(e) => setCliente(e.target.value)}
            placeholder="Filtrar por cliente ou obra"
            className="pl-9"
            aria-label="Filtrar por cliente"
          />
        </div>

        <Select value={montadorId} onValueChange={setMontadorId}>
          <SelectTrigger className="w-full sm:w-[13rem]" aria-label="Filtrar por montador">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todos os montadores</SelectItem>
            {todosColaboradores.map((c) => (
              <SelectItem key={c.id} value={c.id}>
                {c.nome}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {filtrosAtivos && (
          <Button
            variant="ghost"
            size="sm"
            className="w-full sm:w-auto"
            onClick={() => {
              setPeriodo("semana");
              setCliente("");
              setMontadorId("todos");
            }}
          >
            <X className="mr-1 size-4" />
            Limpar filtros
          </Button>
        )}
      </div>

      {montadorSelecionado && (
        <MontadorPainel colaborador={montadorSelecionado} tarefas={tarefas} dias={dias} />
      )}

      <div className="overflow-x-auto rounded-lg plank p-2">
        <TooltipProvider delayDuration={100}>
          <div className="grid min-w-max" style={gridStyle}>
            {/* canto */}
            <div className="sticky left-0 z-30 flex items-end gap-1 border-b border-r border-grid bg-card px-2 pb-2 text-[0.7em] font-semibold uppercase tracking-wider text-muted-foreground">
              <Hammer className="size-3.5" />
              {colabPorLinha ? "Equipe" : "Data"}
            </div>

            {/* cabeçalho do eixo horizontal */}
            {colabPorLinha
              ? dias.map((d) => (
                  <div
                    key={d.index}
                    className={`flex flex-col items-center justify-end border-b border-r border-grid px-1 pb-2 text-center ${
                      d.fimDeSemana ? "bg-weekend" : ""
                    }`}
                  >
                    <span
                      className={`text-[0.65em] uppercase ${
                        d.hoje ? "font-bold text-today" : "text-muted-foreground"
                      }`}
                    >
                      {d.diaSemana}
                    </span>
                    <span
                      className={`text-[0.78em] font-semibold ${d.hoje ? "text-today" : "text-foreground"}`}
                    >
                      {d.label}
                    </span>
                  </div>
                ))
              : colaboradores.map((c) => (
                  <div
                    key={c.id}
                    className="flex flex-col justify-end border-b border-r border-grid px-2 pb-2"
                  >
                    <span className="truncate text-[0.85em] font-semibold">{c.nome}</span>
                    <span className="truncate text-[0.65em] uppercase tracking-wide text-muted-foreground">
                      {c.funcao}
                    </span>
                  </div>
                ))}

            {/* eixo vertical + células de fundo */}
            {Array.from({ length: eixoPrincipal }).map((_, i) => {
              const dia = colabPorLinha ? null : dias[i];
              const colab = colabPorLinha ? colaboradores[i] : null;
              return (
                <div key={`linha-${i}`} className="contents">
                  <div
                    className={`sticky left-0 z-20 flex flex-col justify-center border-b border-r border-grid bg-card px-2 ${
                      dia?.fimDeSemana ? "bg-weekend" : ""
                    }`}
                    style={{ gridRow: i + 2, gridColumn: 1 }}
                  >
                    {colab ? (
                      <>
                        <span className="truncate text-[0.85em] font-semibold">{colab.nome}</span>
                        <span className="truncate text-[0.65em] uppercase tracking-wide text-muted-foreground">
                          {colab.funcao}
                        </span>
                      </>
                    ) : (
                      <>
                        <span
                          className={`text-[0.85em] font-semibold ${dia!.hoje ? "text-today" : ""}`}
                        >
                          {dia!.label}
                        </span>
                        <span className="text-[0.65em] uppercase text-muted-foreground">
                          {dia!.diaSemana}
                        </span>
                      </>
                    )}
                  </div>

                  {Array.from({ length: eixoSecundario }).map((__, j) => {
                    const fds = colabPorLinha ? !!dias[j]?.fimDeSemana : dia!.fimDeSemana;
                    const hoje = colabPorLinha ? !!dias[j]?.hoje : dia!.hoje;
                    return (
                      <div
                        key={`cel-${i}-${j}`}
                        style={{ gridRow: i + 2, gridColumn: j + 2 }}
                        className={`border-b border-r border-grid ${fds ? "bg-weekend" : ""} ${
                          hoje ? "ring-1 ring-inset ring-today/40" : ""
                        }`}
                      />
                    );
                  })}
                </div>
              );
            })}

            {/* barras */}
            {tarefas.map((t) => {
              const ci = colaboradores.findIndex((c) => c.id === t.colaboradorId);
              if (ci < 0) return null;
              const inicio = Math.max(0, t.inicio);
              const fim = Math.min(ultimoDia, t.inicio + t.dias - 1);
              const span = Math.max(1, fim - inicio + 1);
              const pos = colabPorLinha
                ? { gridRow: ci + 2, gridColumn: `${inicio + 2} / span ${span}` }
                : { gridRow: `${inicio + 2} / span ${span}`, gridColumn: ci + 2 };

              return (
                <Tooltip key={t.id}>
                  <TooltipTrigger asChild>
                    <button
                      type="button"
                      style={pos}
                      onClick={() => setTarefaEditando(t)}
                      aria-label={`Editar ${t.obra}`}
                      className={`z-10 m-1 flex cursor-pointer items-center overflow-hidden rounded-md px-2 text-left text-phase-fg shadow-sm transition-transform hover:scale-[1.02] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${
                        faseClass[t.fase]
                      } ${colabPorLinha ? "" : "items-start pt-1"}`}
                    >
                      <span className="truncate text-[0.75em] font-semibold">{t.obra}</span>
                    </button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="font-semibold">{t.obra}</p>
                    <p className="text-xs">Cliente: {t.cliente}</p>
                    <p className="text-xs">{faseLabel[t.fase]}</p>
                    <p className="text-xs">
                      {dias[t.inicio]?.label} →{" "}
                      {dias[Math.min(t.inicio + t.dias - 1, dias.length - 1)]?.label} · {t.dias} dias
                    </p>
                  </TooltipContent>
                </Tooltip>
              );
            })}
          </div>
        </TooltipProvider>
      </div>

      <div className="flex flex-wrap items-center gap-3">
        {(Object.keys(faseLabel) as Fase[]).map((f) => (
          <Badge key={f} variant="outline" className="gap-2 font-normal">
            <span className={`size-3 rounded-sm ${faseClass[f]}`} />
            {faseLabel[f]}
          </Badge>
        ))}
        <span className="text-xs text-muted-foreground">
          Dica: clique em uma barra para editar o serviço rapidamente.
        </span>
      </div>

      <EdicaoRapidaDialog
        tarefa={tarefaEditando}
        dias={dias}
        onClose={() => setTarefaEditando(null)}
      />
    </section>
  );
}
