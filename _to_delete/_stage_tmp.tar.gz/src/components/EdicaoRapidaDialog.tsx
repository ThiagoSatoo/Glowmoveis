import { useEffect, useState } from "react";
import { Save, Trash2 } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { faseLabel, type Dia, type Fase, type Tarefa } from "@/lib/gantt-data";
import { useGantt } from "@/lib/gantt-store";

const fases = Object.keys(faseLabel) as Fase[];

type Props = {
  tarefa: Tarefa | null;
  dias: Dia[];
  onClose: () => void;
};

export function EdicaoRapidaDialog({ tarefa, dias, onClose }: Props) {
  const { colaboradores, salvarTarefa, removerTarefa, desfazer, refazer } = useGantt();

  function avisarComRefazer(mensagem = "Ação desfeita.") {
    toast(mensagem, {
      action: {
        label: "Refazer",
        onClick: () => {
          refazer();
          avisarComDesfazer("Ação refeita.");
        },
      },
      duration: 6000,
    });
  }

  function avisarComDesfazer(mensagem: string) {
    toast(mensagem, {
      action: {
        label: "Desfazer",
        onClick: () => {
          desfazer();
          avisarComRefazer();
        },
      },
      duration: 6000,
    });
  }

  const [obra, setObra] = useState("");
  const [cliente, setCliente] = useState("");
  const [fase, setFase] = useState<Fase>("corte");
  const [responsavel, setResponsavel] = useState("");
  const [inicio, setInicio] = useState("0");
  const [duracao, setDuracao] = useState("1");

  useEffect(() => {
    if (tarefa) {
      setObra(tarefa.obra);
      setCliente(tarefa.cliente);
      setFase(tarefa.fase);
      setResponsavel(tarefa.colaboradorId);
      setInicio(String(tarefa.inicio));
      setDuracao(String(tarefa.dias));
    }
  }, [tarefa]);

  const salvar = () => {
    if (!tarefa || !obra.trim()) return;
    salvarTarefa({
      id: tarefa.id,
      obra: obra.trim(),
      cliente: cliente.trim() || "Sem cliente",
      fase,
      colaboradorId: responsavel || tarefa.colaboradorId,
      inicio: Number(inicio),
      dias: Math.max(1, Number(duracao) || 1),
    });
    avisarComDesfazer(`Serviço "${obra.trim()}" salvo.`);
    onClose();
  };

  const excluir = () => {
    if (!tarefa) return;
    removerTarefa(tarefa.id);
    avisarComDesfazer(`Serviço "${tarefa.obra}" excluído.`);
    onClose();
  };

  return (
    <Dialog open={!!tarefa} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Edição rápida</DialogTitle>
          <DialogDescription>
            Ajuste o serviço direto do cronograma, sem abrir o gerenciador.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-3 sm:grid-cols-2">
          <div className="space-y-1.5 sm:col-span-2">
            <Label htmlFor="er-obra">Serviço / obra</Label>
            <Input id="er-obra" value={obra} onChange={(e) => setObra(e.target.value)} />
          </div>
          <div className="space-y-1.5 sm:col-span-2">
            <Label htmlFor="er-cliente">Cliente</Label>
            <Input id="er-cliente" value={cliente} onChange={(e) => setCliente(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label>Etapa</Label>
            <Select value={fase} onValueChange={(v) => setFase(v as Fase)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {fases.map((f) => (
                  <SelectItem key={f} value={f}>
                    {faseLabel[f]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Responsável</Label>
            <Select value={responsavel} onValueChange={setResponsavel}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {colaboradores.map((c) => (
                  <SelectItem key={c.id} value={c.id}>
                    {c.nome}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Início</Label>
            <Select value={inicio} onValueChange={setInicio}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {dias.map((d) => (
                  <SelectItem key={d.index} value={String(d.index)}>
                    {d.label} ({d.diaSemana})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="er-duracao">Duração (dias)</Label>
            <Input
              id="er-duracao"
              type="number"
              min={1}
              max={dias.length}
              value={duracao}
              onChange={(e) => setDuracao(e.target.value)}
            />
          </div>
        </div>

        <DialogFooter className="gap-2 sm:justify-between">
          <Button variant="ghost" className="text-destructive" onClick={excluir}>
            <Trash2 className="mr-2 size-4" />
            Excluir
          </Button>
          <div className="flex gap-2">
            <Button variant="secondary" onClick={onClose}>
              Cancelar
            </Button>
            <Button onClick={salvar}>
              <Save className="mr-2 size-4" />
              Salvar
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
