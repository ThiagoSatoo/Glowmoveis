export type Fase = "corte" | "montagem" | "acabamento" | "entrega";

export type Colaborador = {
  id: string;
  nome: string;
  funcao: string;
};

export type Tarefa = {
  id: string;
  colaboradorId: string;
  obra: string;
  /** nome do cliente */
  cliente: string;
  fase: Fase;
  /** índice do dia inicial na linha do tempo (0-based) */
  inicio: number;
  /** duração em dias */
  dias: number;
};

export const faseLabel: Record<Fase, string> = {
  corte: "Corte / Usinagem",
  montagem: "Montagem",
  acabamento: "Acabamento / Pintura",
  entrega: "Instalação / Entrega",
};

export const faseClass: Record<Fase, string> = {
  corte: "bg-phase-corte",
  montagem: "bg-phase-montagem",
  acabamento: "bg-phase-acabamento",
  entrega: "bg-phase-entrega",
};

export const colaboradores: Colaborador[] = [
  { id: "c1", nome: "Seu Antônio", funcao: "Mestre marceneiro" },
  { id: "c2", nome: "Rafael Lima", funcao: "Operador CNC" },
  { id: "c3", nome: "Cláudia Reis", funcao: "Acabamento" },
  { id: "c4", nome: "Douglas Prado", funcao: "Montador" },
  { id: "c5", nome: "Marina Alves", funcao: "Instalação" },
];

export const tarefas: Tarefa[] = [
  { id: "t1", colaboradorId: "c1", obra: "Cozinha Apto 302", cliente: "Fernanda Rocha", fase: "corte", inicio: 0, dias: 3 },
  { id: "t2", colaboradorId: "c1", obra: "Balcão Padaria Pão&Cia", cliente: "Padaria Pão & Cia", fase: "montagem", inicio: 4, dias: 4 },
  { id: "t3", colaboradorId: "c1", obra: "Mesa 8 lugares", cliente: "Marcos Tavares", fase: "acabamento", inicio: 10, dias: 3 },
  { id: "t4", colaboradorId: "c2", obra: "Cozinha Apto 302", cliente: "Fernanda Rocha", fase: "corte", inicio: 0, dias: 2 },
  { id: "t5", colaboradorId: "c2", obra: "Closet Casa Bela Vista", cliente: "Família Bela Vista", fase: "corte", inicio: 3, dias: 4 },
  { id: "t6", colaboradorId: "c2", obra: "Painel TV Ripado", cliente: "Juliana Prado", fase: "corte", inicio: 8, dias: 3 },
  { id: "t7", colaboradorId: "c3", obra: "Mesa 8 lugares", cliente: "Marcos Tavares", fase: "acabamento", inicio: 1, dias: 4 },
  { id: "t8", colaboradorId: "c3", obra: "Painel TV Ripado", cliente: "Juliana Prado", fase: "acabamento", inicio: 6, dias: 5 },
  { id: "t9", colaboradorId: "c4", obra: "Closet Casa Bela Vista", cliente: "Família Bela Vista", fase: "montagem", inicio: 2, dias: 5 },
  { id: "t10", colaboradorId: "c4", obra: "Cozinha Apto 302", cliente: "Fernanda Rocha", fase: "montagem", inicio: 8, dias: 4 },
  { id: "t11", colaboradorId: "c5", obra: "Balcão Padaria Pão&Cia", cliente: "Padaria Pão & Cia", fase: "entrega", inicio: 5, dias: 2 },
  { id: "t12", colaboradorId: "c5", obra: "Closet Casa Bela Vista", cliente: "Família Bela Vista", fase: "entrega", inicio: 9, dias: 2 },
  { id: "t13", colaboradorId: "c5", obra: "Cozinha Apto 302", cliente: "Fernanda Rocha", fase: "entrega", inicio: 12, dias: 2 },
];

const semana = ["dom", "seg", "ter", "qua", "qui", "sex", "sáb"];

export type Dia = {
  index: number;
  label: string;
  diaSemana: string;
  fimDeSemana: boolean;
  hoje: boolean;
};

export type Periodo = "dia" | "semana" | "mes" | "ano";

export const periodoLabel: Record<Periodo, string> = {
  dia: "Dia",
  semana: "Semana",
  mes: "Mês",
  ano: "Ano",
};

export const periodoDias: Record<Periodo, number> = {
  dia: 1,
  semana: 7,
  mes: 30,
  ano: 365,
};

/** Linha do tempo em dias começando na segunda-feira da semana atual. */
export function gerarDias(total = 14): Dia[] {
  const hoje = new Date();
  const base = new Date(hoje);
  const offset = (base.getDay() + 6) % 7; // segunda = 0
  base.setDate(base.getDate() - offset);

  return Array.from({ length: total }, (_, i) => {
    const d = new Date(base);
    d.setDate(base.getDate() + i);
    return {
      index: i,
      label: `${String(d.getDate()).padStart(2, "0")}/${String(d.getMonth() + 1).padStart(2, "0")}`,
      diaSemana: semana[d.getDay()]!,
      fimDeSemana: d.getDay() === 0 || d.getDay() === 6,
      hoje: d.toDateString() === hoje.toDateString(),
    };
  });
}
