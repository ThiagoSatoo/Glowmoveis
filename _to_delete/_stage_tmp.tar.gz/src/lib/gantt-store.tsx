import { useSyncExternalStore, type ReactNode } from "react";

import {
  colaboradores as colaboradoresIniciais,
  tarefas as tarefasIniciais,
  type Colaborador,
  type Tarefa,
} from "./gantt-data";

type State = {
  colaboradores: Colaborador[];
  tarefas: Tarefa[];
};

type Store = State & {
  salvarColaborador: (c: Omit<Colaborador, "id"> & { id?: string | undefined }) => void;
  removerColaborador: (id: string) => void;
  salvarTarefa: (t: Omit<Tarefa, "id"> & { id?: string | undefined }) => void;
  removerTarefa: (id: string) => void;
  desfazer: () => void;
  refazer: () => void;
  podeDesfazer: boolean;
  podeRefazer: boolean;
};

const novoId = (prefixo: string) =>
  `${prefixo}${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;

let state: State = { colaboradores: colaboradoresIniciais, tarefas: tarefasIniciais };
const historico: State[] = [];
const historicoRefazer: State[] = [];
const LIMITE_HISTORICO = 50;
let podeDesfazer = false;
let podeRefazer = false;
const listeners = new Set<() => void>();

const atualizarFlags = () => {
  podeDesfazer = historico.length > 0;
  podeRefazer = historicoRefazer.length > 0;
};

const registrarHistorico = () => {
  historico.push(state);
  if (historico.length > LIMITE_HISTORICO) historico.shift();
  historicoRefazer.length = 0;
  atualizarFlags();
};

export const temDesfazer = () => podeDesfazer;
export const temRefazer = () => podeRefazer;

type Snapshot = State & { podeDesfazer: boolean; podeRefazer: boolean };
let snapshot: Snapshot = { ...state, podeDesfazer: false, podeRefazer: false };

const setState = (parcial: Partial<State>) => {
  state = { ...state, ...parcial };
  snapshot = { ...state, podeDesfazer, podeRefazer };
  listeners.forEach((l) => l());
};

const subscribe = (l: () => void) => {
  listeners.add(l);
  return () => listeners.delete(l);
};

const getSnapshot = () => snapshot;

const acoes = {
  salvarColaborador: (c: Omit<Colaborador, "id"> & { id?: string | undefined }) => {
    registrarHistorico();
    setState({
      colaboradores: c.id
        ? state.colaboradores.map((x) => (x.id === c.id ? { ...x, ...c, id: c.id! } : x))
        : [...state.colaboradores, { ...c, id: novoId("c") }],
    });
  },
  removerColaborador: (id: string) => {
    registrarHistorico();
    setState({
      colaboradores: state.colaboradores.filter((c) => c.id !== id),
      tarefas: state.tarefas.filter((t) => t.colaboradorId !== id),
    });
  },
  salvarTarefa: (t: Omit<Tarefa, "id"> & { id?: string | undefined }) => {
    registrarHistorico();
    setState({
      tarefas: t.id
        ? state.tarefas.map((x) => (x.id === t.id ? { ...x, ...t, id: t.id! } : x))
        : [...state.tarefas, { ...t, id: novoId("t") }],
    });
  },
  removerTarefa: (id: string) => {
    registrarHistorico();
    setState({ tarefas: state.tarefas.filter((t) => t.id !== id) });
  },
  desfazer: () => {
    const anterior = historico.pop();
    if (!anterior) return;
    historicoRefazer.push(state);
    if (historicoRefazer.length > LIMITE_HISTORICO) historicoRefazer.shift();
    atualizarFlags();
    setState(anterior);
  },
  refazer: () => {
    const proximo = historicoRefazer.pop();
    if (!proximo) return;
    historico.push(state);
    if (historico.length > LIMITE_HISTORICO) historico.shift();
    atualizarFlags();
    setState(proximo);
  },
};

/** Mantido por compatibilidade: o estado agora é global, sem necessidade de contexto. */
export function GanttProvider({ children }: { children: ReactNode }) {
  return <>{children}</>;
}

export function useGantt(): Store {
  const snap = useSyncExternalStore(subscribe, getSnapshot, getSnapshot);
  return { ...snap, ...acoes };
}
